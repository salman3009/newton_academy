export function sayHi(user) {
  alert(`Hello, ${user}!`);
}  // no ; at the end