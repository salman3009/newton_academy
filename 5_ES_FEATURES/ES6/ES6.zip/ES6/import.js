
import * as say from './export.js';
say.sayHi('John');
