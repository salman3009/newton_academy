# Tribute-Page-Tim-berners-Lee
Hello, I am Athar
This is my first simple project, a tribute site, dedicated to Sir Tim Berners Lee, Creater of WWW. I made this project while learning HTML and CSS.
